﻿namespace FormsProiect
{
    partial class InsertForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.quantityBox = new System.Windows.Forms.TextBox();
            this.nameBox = new System.Windows.Forms.TextBox();
            this.property3Label = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.property1Label = new System.Windows.Forms.Label();
            this.property2Label = new System.Windows.Forms.Label();
            this.property1Box = new System.Windows.Forms.TextBox();
            this.property2Box = new System.Windows.Forms.TextBox();
            this.property3Box = new System.Windows.Forms.TextBox();
            this.categoryLabel = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.Controls.Add(this.quantityBox, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.nameBox, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.property3Label, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.label7, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.label3, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.property1Label, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.property2Label, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.property1Box, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.property2Box, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.property3Box, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.categoryLabel, 1, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(12, 12);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 7;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 62F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 44.76744F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 55.23256F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 72F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 83F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 62F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(377, 452);
            this.tableLayoutPanel1.TabIndex = 2;
            // 
            // quantityBox
            // 
            this.quantityBox.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.quantityBox.Location = new System.Drawing.Point(61, 176);
            this.quantityBox.Name = "quantityBox";
            this.quantityBox.Size = new System.Drawing.Size(314, 20);
            this.quantityBox.TabIndex = 14;
            // 
            // nameBox
            // 
            this.nameBox.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.nameBox.Location = new System.Drawing.Point(61, 90);
            this.nameBox.Name = "nameBox";
            this.nameBox.Size = new System.Drawing.Size(314, 20);
            this.nameBox.TabIndex = 12;
            // 
            // property3Label
            // 
            this.property3Label.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.property3Label.AutoSize = true;
            this.property3Label.Location = new System.Drawing.Point(3, 414);
            this.property3Label.Name = "property3Label";
            this.property3Label.Size = new System.Drawing.Size(52, 13);
            this.property3Label.TabIndex = 10;
            this.property3Label.Text = "Property3";
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 180);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(46, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Quantity";
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(4, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Category";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(11, 94);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Name";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // property1Label
            // 
            this.property1Label.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.property1Label.AutoSize = true;
            this.property1Label.Location = new System.Drawing.Point(3, 263);
            this.property1Label.Name = "property1Label";
            this.property1Label.Size = new System.Drawing.Size(52, 13);
            this.property1Label.TabIndex = 9;
            this.property1Label.Text = "Property1";
            // 
            // property2Label
            // 
            this.property2Label.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.property2Label.AutoSize = true;
            this.property2Label.Location = new System.Drawing.Point(3, 341);
            this.property2Label.Name = "property2Label";
            this.property2Label.Size = new System.Drawing.Size(52, 13);
            this.property2Label.TabIndex = 8;
            this.property2Label.Text = "Property2";
            // 
            // property1Box
            // 
            this.property1Box.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.property1Box.Location = new System.Drawing.Point(61, 260);
            this.property1Box.Name = "property1Box";
            this.property1Box.Size = new System.Drawing.Size(314, 20);
            this.property1Box.TabIndex = 15;
            // 
            // property2Box
            // 
            this.property2Box.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.property2Box.Location = new System.Drawing.Point(61, 337);
            this.property2Box.Name = "property2Box";
            this.property2Box.Size = new System.Drawing.Size(314, 20);
            this.property2Box.TabIndex = 16;
            // 
            // property3Box
            // 
            this.property3Box.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.property3Box.Location = new System.Drawing.Point(61, 410);
            this.property3Box.Name = "property3Box";
            this.property3Box.Size = new System.Drawing.Size(314, 20);
            this.property3Box.TabIndex = 17;
            // 
            // categoryLabel
            // 
            this.categoryLabel.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.categoryLabel.AutoSize = true;
            this.categoryLabel.Location = new System.Drawing.Point(61, 24);
            this.categoryLabel.Name = "categoryLabel";
            this.categoryLabel.Size = new System.Drawing.Size(52, 13);
            this.categoryLabel.TabIndex = 18;
            this.categoryLabel.Text = "Categorie";
            this.categoryLabel.Click += new System.EventHandler(this.categoryLabel_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(312, 470);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 3;
            this.button1.Text = "Add";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // InsertForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(399, 505);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "InsertForm";
            this.Text = "InsertForm";
            this.Load += new System.EventHandler(this.InsertForm_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label property3Label;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label property1Label;
        private System.Windows.Forms.Label property2Label;
        private System.Windows.Forms.TextBox quantityBox;
        private System.Windows.Forms.TextBox nameBox;
        private System.Windows.Forms.TextBox property1Box;
        private System.Windows.Forms.TextBox property2Box;
        private System.Windows.Forms.TextBox property3Box;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label categoryLabel;
    }
}