﻿namespace FormsProiect
{
    partial class ViewForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.property3TextLabel = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.categoryLabel = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.property1TextLabel = new System.Windows.Forms.Label();
            this.property2TextLabel = new System.Windows.Forms.Label();
            this.nameLabel = new System.Windows.Forms.Label();
            this.property1ValueLabel = new System.Windows.Forms.Label();
            this.property2ValueLabel = new System.Windows.Forms.Label();
            this.property3ValueLabel = new System.Windows.Forms.Label();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.quantityLabel = new System.Windows.Forms.Label();
            this.quantityButton = new System.Windows.Forms.Button();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(4, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Category";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.Controls.Add(this.property3TextLabel, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.label7, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.categoryLabel, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label3, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.property1TextLabel, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.property2TextLabel, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.nameLabel, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.property1ValueLabel, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.property2ValueLabel, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.property3ValueLabel, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 1, 2);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(12, 12);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 7;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 62F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 39.80582F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 60.19418F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 91F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 58F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 62F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(389, 452);
            this.tableLayoutPanel1.TabIndex = 1;
            this.tableLayoutPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel1_Paint);
            // 
            // property3TextLabel
            // 
            this.property3TextLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.property3TextLabel.AutoSize = true;
            this.property3TextLabel.Location = new System.Drawing.Point(3, 414);
            this.property3TextLabel.Name = "property3TextLabel";
            this.property3TextLabel.Size = new System.Drawing.Size(52, 13);
            this.property3TextLabel.TabIndex = 10;
            this.property3TextLabel.Text = "Property3";
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 180);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(46, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Quantity";
            // 
            // categoryLabel
            // 
            this.categoryLabel.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.categoryLabel.AutoSize = true;
            this.categoryLabel.Location = new System.Drawing.Point(61, 24);
            this.categoryLabel.Name = "categoryLabel";
            this.categoryLabel.Size = new System.Drawing.Size(46, 13);
            this.categoryLabel.TabIndex = 1;
            this.categoryLabel.Text = "Suruburi";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(11, 91);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Name";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // property1TextLabel
            // 
            this.property1TextLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.property1TextLabel.AutoSize = true;
            this.property1TextLabel.Location = new System.Drawing.Point(3, 279);
            this.property1TextLabel.Name = "property1TextLabel";
            this.property1TextLabel.Size = new System.Drawing.Size(52, 13);
            this.property1TextLabel.TabIndex = 9;
            this.property1TextLabel.Text = "Property1";
            // 
            // property2TextLabel
            // 
            this.property2TextLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.property2TextLabel.AutoSize = true;
            this.property2TextLabel.Location = new System.Drawing.Point(3, 353);
            this.property2TextLabel.Name = "property2TextLabel";
            this.property2TextLabel.Size = new System.Drawing.Size(52, 13);
            this.property2TextLabel.TabIndex = 8;
            this.property2TextLabel.Text = "Property2";
            // 
            // nameLabel
            // 
            this.nameLabel.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.nameLabel.AutoSize = true;
            this.nameLabel.Location = new System.Drawing.Point(61, 91);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(46, 13);
            this.nameLabel.TabIndex = 11;
            this.nameLabel.Text = "Suruburi";
            // 
            // property1ValueLabel
            // 
            this.property1ValueLabel.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.property1ValueLabel.AutoSize = true;
            this.property1ValueLabel.Location = new System.Drawing.Point(61, 279);
            this.property1ValueLabel.Name = "property1ValueLabel";
            this.property1ValueLabel.Size = new System.Drawing.Size(46, 13);
            this.property1ValueLabel.TabIndex = 14;
            this.property1ValueLabel.Text = "Suruburi";
            // 
            // property2ValueLabel
            // 
            this.property2ValueLabel.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.property2ValueLabel.AutoSize = true;
            this.property2ValueLabel.Location = new System.Drawing.Point(61, 353);
            this.property2ValueLabel.Name = "property2ValueLabel";
            this.property2ValueLabel.Size = new System.Drawing.Size(46, 13);
            this.property2ValueLabel.TabIndex = 15;
            this.property2ValueLabel.Text = "Suruburi";
            // 
            // property3ValueLabel
            // 
            this.property3ValueLabel.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.property3ValueLabel.AutoSize = true;
            this.property3ValueLabel.Location = new System.Drawing.Point(61, 414);
            this.property3ValueLabel.Name = "property3ValueLabel";
            this.property3ValueLabel.Size = new System.Drawing.Size(46, 13);
            this.property3ValueLabel.TabIndex = 16;
            this.property3ValueLabel.Text = "Suruburi";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 44.44444F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 55.55556F));
            this.tableLayoutPanel2.Controls.Add(this.quantityButton, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.quantityLabel, 0, 0);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(66, 154);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(314, 65);
            this.tableLayoutPanel2.TabIndex = 17;
            // 
            // quantityLabel
            // 
            this.quantityLabel.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.quantityLabel.AutoSize = true;
            this.quantityLabel.Location = new System.Drawing.Point(3, 26);
            this.quantityLabel.Name = "quantityLabel";
            this.quantityLabel.Size = new System.Drawing.Size(46, 13);
            this.quantityLabel.TabIndex = 13;
            this.quantityLabel.Text = "Suruburi";
            // 
            // quantityButton
            // 
            this.quantityButton.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.quantityButton.BackColor = System.Drawing.SystemColors.ControlLight;
            this.quantityButton.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.quantityButton.Location = new System.Drawing.Point(278, 18);
            this.quantityButton.Name = "quantityButton";
            this.quantityButton.Size = new System.Drawing.Size(33, 28);
            this.quantityButton.TabIndex = 15;
            this.quantityButton.Text = "-";
            this.quantityButton.UseVisualStyleBackColor = false;
            this.quantityButton.Click += new System.EventHandler(this.quantityButton_Click);
            // 
            // ViewForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(413, 473);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "ViewForm";
            this.Text = "ViewForm";
            this.Load += new System.EventHandler(this.ViewForm_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label categoryLabel;
        private System.Windows.Forms.Label property3TextLabel;
        private System.Windows.Forms.Label property1TextLabel;
        private System.Windows.Forms.Label property2TextLabel;
        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.Label property1ValueLabel;
        private System.Windows.Forms.Label property2ValueLabel;
        private System.Windows.Forms.Label property3ValueLabel;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label quantityLabel;
        private System.Windows.Forms.Button quantityButton;
    }
}