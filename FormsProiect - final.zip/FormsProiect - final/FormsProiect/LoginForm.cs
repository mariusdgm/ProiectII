﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormsProiect
{
    public partial class LoginForm : Form
    {
        FormsProiect.ServiceReference1.WebSrvSoapClient service = new FormsProiect.ServiceReference1.WebSrvSoapClient();
        public LoginForm()
        {
            InitializeComponent();
        }

        private void log_button_Click(object sender, EventArgs e)
        {
            if ((service.check_login(user_text.Text, pass_text.Text)) == 1)
            {
                new BrowseForm().Show();
            }
            else
            {
                MessageBox.Show("Incorrect username or password!");
            }
        }

        private void cancel_button_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}