﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormsProiect
{
    public partial class ViewForm : Form
    {
        FormsProiect.ServiceReference1.WebSrvSoapClient service = new FormsProiect.ServiceReference1.WebSrvSoapClient();
        int prodQuantity = 0;
        int selectedProdId = 0;

        public ViewForm(DataRow dataToShow)
        {
            InitializeComponent();

            nameLabel.Text = dataToShow["Nume"].ToString();
            categoryLabel.Text = dataToShow["NumeCategorie"].ToString();
            quantityLabel.Text = dataToShow["Quantity"].ToString();
            property1ValueLabel.Text = dataToShow["PropertyValue1"].ToString();
            property2ValueLabel.Text = dataToShow["PropertyValue2"].ToString();
            property3ValueLabel.Text = dataToShow["PropertyValue3"].ToString();
            property1TextLabel.Text = dataToShow["PropertyName1"].ToString();
            property2TextLabel.Text = dataToShow["PropertyName2"].ToString();
            property3TextLabel.Text = dataToShow["PropertyName3"].ToString();
            this.prodQuantity = Int32.Parse(dataToShow["Quantity"].ToString());
        }

        private void ViewForm_Load(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void quantityButton_Click(object sender, EventArgs e)
        {
            service.update_product_quantity(BrowseForm.selectedProdId, prodQuantity - 1);
            quantityLabel.Text = (Int32.Parse(quantityLabel.Text) - 1).ToString();
        }
    }
}