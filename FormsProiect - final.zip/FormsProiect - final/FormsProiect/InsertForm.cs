﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormsProiect
{
    public partial class InsertForm : Form
    {
        int catID = 0;
        public InsertForm(DataRow dataToShow, int index, string catName)
        {
            InitializeComponent();
            this.catID = index;
            categoryLabel.Text = catName;

            //categoryLabel.Text = dataToShow["Nume"].ToString();
            property1Label.Text = dataToShow["PropertyName1"].ToString();
            property2Label.Text = dataToShow["PropertyName2"].ToString();
            property3Label.Text = dataToShow["PropertyName3"].ToString();
        }

        private void InsertForm_Load(object sender, EventArgs e) {

        }

        private void categoryLabel_Click(object sender, EventArgs e) {

        }

        private void button1_Click(object sender, EventArgs e) {
            FormsProiect.ServiceReference1.WebSrvSoapClient service = new FormsProiect.ServiceReference1.WebSrvSoapClient();
            service.add_product(catID+1, nameBox.Text, property1Box.Text, property2Box.Text, property3Box.Text, Int32.Parse(quantityBox.Text));
            
        }
    }
}