﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormsProiect
{
    public partial class BrowseForm : Form
    {
        FormsProiect.ServiceReference1.WebSrvSoapClient service = new FormsProiect.ServiceReference1.WebSrvSoapClient();
        List<String> idCatList = new List<String>();
        List<String> nameCatList = new List<String>();
        List<String> idProdList = new List<String>();
        List<String> nameProdList = new List<String>();
        public static int selectedProdId = 0;

        public BrowseForm()
        {
            InitializeComponent();
        }
        
        private void b_populate_list_click(object sender, EventArgs e)
        {
            
        }

        private void BrowseForm_Load(object sender, EventArgs e) {
            DataSet result = service.get_category_list();
            DataTable tabela = result.Tables[0];
            foreach(DataRow rand in tabela.Rows) {
                cat_list.Items.Add(rand["NumeCategorie"]);
                idCatList.Add(rand["IdCategorie"].ToString());
                nameCatList.Add(rand["NumeCategorie"].ToString());
            }
        }

        private void cat_list_SelectedIndexChanged(object sender, EventArgs e) {
            int index = cat_list.SelectedIndex;
            if (index != -1) {
                Console.WriteLine(idCatList[index] + " " + nameCatList[index]);

                // clear what is shown in product list
                prod_list.Items.Clear();
                idProdList.Clear();
                nameProdList.Clear();

                //disable buttons, because nothing is selected yet @ products
                viewButton.Enabled = false;
                deleteButton.Enabled = false;

                // but a category is selected so we can insert things in it
                insertButton.Enabled = true;

                DataSet dataSet = service.get_products_from_category(Int32.Parse(idCatList[index]));
                DataTable tabela = dataSet.Tables[0];
                foreach (DataRow rand in tabela.Rows) {
                    Console.WriteLine(rand["IdPiesa"] + " " + rand["Nume"]);
                    prod_list.Items.Add(rand["Nume"]);
                    idProdList.Add(rand["IdPiesa"].ToString());
                    nameProdList.Add(rand["Nume"].ToString());
                }
            }
        }

        private void prod_list_SelectedIndexChanged(object sender, EventArgs e) {
            if (prod_list.SelectedIndex != -1) {
                viewButton.Enabled = true;
                deleteButton.Enabled = true;
            }
            selectedProdId = prod_list.SelectedIndex;
        }

        private void viewButton_Click(object sender, EventArgs e) {
            DataSet dataSet = service.get_product_details(Int32.Parse(idProdList[prod_list.SelectedIndex]));
            DataTable table = dataSet.Tables[0];
            DataRow rand = table.Rows[0];
            ViewForm viewForm = new ViewForm(rand);
            viewForm.Show();
        }

        private void label1_Click(object sender, EventArgs e) {

        }

        private void deleteButton_Click(object sender, EventArgs e) {
            try {
                int listIndex = prod_list.SelectedIndex;
                int prodId = Int32.Parse(idProdList[listIndex]);

                Console.WriteLine("DELETE " + prodId);
                service.delete_product(prodId);
            } catch(Exception exception) {
                Console.WriteLine(exception.ToString());
            }

            prod_list.Items.RemoveAt(prod_list.SelectedIndex);
            //prod_list.SelectedIndex = prod_list.Items.IndexOf(SelectedObject);
        }

        private void insertButton_Click(object sender, EventArgs e) {
            int index = cat_list.SelectedIndex;
            DataSet dataSet = service.get_category_property_names(Int32.Parse(idCatList[cat_list.SelectedIndex]));
            DataTable table = dataSet.Tables[0];
            DataRow dataToShow = table.Rows[0];
            InsertForm insertForm = new InsertForm(dataToShow, index, nameCatList[index]);
            insertForm.Show();
        }
    }
}
